
<h1 align="center">
<img src="/branding/logo.svg" width="500">
</h1><br>

###### Attribution required : Fabien Furfaro (CC 4.0 BY NC ND SA)

(Work in developpement)

See the notebook [here](/.ipynb) (Work in progress)

An Artificial Neural Network Functionalized by Evolution - This model is based on this [paper](https://arxiv.org/abs/2205.10118).


**Requirements :**

	numpy
	pandas
	torch
	torchvision
	networkx


